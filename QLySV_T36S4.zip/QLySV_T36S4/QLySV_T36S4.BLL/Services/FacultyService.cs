﻿using QLySV_T36S4.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLySV_T36S4.BLL.Services
{
    public class FacultyService
    {
        //khai bao csdl
        private static QLSV_Entities dbContext;
        public FacultyService()
        {
            //ket noi toi csdl
            dbContext = new QLSV_Entities();
        }
        //doc du lieu
        public List<Faculty> GetAllFaculties()
        {
            return dbContext.Faculty.ToList();
        }

        public Faculty GetFaculty(int id)
        {
            return dbContext.Faculty.Find(id);
        }
        //tao moi du lieu

        //thay doi du lieu

        //xoa
    }
}
