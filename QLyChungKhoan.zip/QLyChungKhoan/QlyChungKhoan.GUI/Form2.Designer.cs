﻿namespace QlyChungKhoan.GUI
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cb_MaCK = new System.Windows.Forms.ComboBox();
            this.txt_SoTien = new System.Windows.Forms.TextBox();
            this.rdo_Nu = new System.Windows.Forms.RadioButton();
            this.rdo_nam = new System.Windows.Forms.RadioButton();
            this.txt_TenKH = new System.Windows.Forms.TextBox();
            this.txt_MaKH = new System.Windows.Forms.TextBox();
            this.lbl_SoTien = new System.Windows.Forms.Label();
            this.lbl_MaCK = new System.Windows.Forms.Label();
            this.lbl_Gioi = new System.Windows.Forms.Label();
            this.lbl_TenKH = new System.Windows.Forms.Label();
            this.lbl_MaKH = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_exit2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cb_MaCK);
            this.groupBox1.Controls.Add(this.txt_SoTien);
            this.groupBox1.Controls.Add(this.rdo_Nu);
            this.groupBox1.Controls.Add(this.rdo_nam);
            this.groupBox1.Controls.Add(this.txt_TenKH);
            this.groupBox1.Controls.Add(this.txt_MaKH);
            this.groupBox1.Controls.Add(this.lbl_SoTien);
            this.groupBox1.Controls.Add(this.lbl_MaCK);
            this.groupBox1.Controls.Add(this.lbl_Gioi);
            this.groupBox1.Controls.Add(this.lbl_TenKH);
            this.groupBox1.Controls.Add(this.lbl_MaKH);
            this.groupBox1.Location = new System.Drawing.Point(240, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 304);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quan ly khach hang";
            // 
            // cb_MaCK
            // 
            this.cb_MaCK.FormattingEnabled = true;
            this.cb_MaCK.Location = new System.Drawing.Point(139, 204);
            this.cb_MaCK.Name = "cb_MaCK";
            this.cb_MaCK.Size = new System.Drawing.Size(169, 24);
            this.cb_MaCK.TabIndex = 9;
            // 
            // txt_SoTien
            // 
            this.txt_SoTien.Location = new System.Drawing.Point(139, 253);
            this.txt_SoTien.Name = "txt_SoTien";
            this.txt_SoTien.Size = new System.Drawing.Size(169, 22);
            this.txt_SoTien.TabIndex = 8;
            // 
            // rdo_Nu
            // 
            this.rdo_Nu.AutoSize = true;
            this.rdo_Nu.Location = new System.Drawing.Point(190, 149);
            this.rdo_Nu.Name = "rdo_Nu";
            this.rdo_Nu.Size = new System.Drawing.Size(45, 20);
            this.rdo_Nu.TabIndex = 7;
            this.rdo_Nu.TabStop = true;
            this.rdo_Nu.Text = "Nu";
            this.rdo_Nu.UseVisualStyleBackColor = true;
            // 
            // rdo_nam
            // 
            this.rdo_nam.AutoSize = true;
            this.rdo_nam.Location = new System.Drawing.Point(84, 149);
            this.rdo_nam.Name = "rdo_nam";
            this.rdo_nam.Size = new System.Drawing.Size(57, 20);
            this.rdo_nam.TabIndex = 6;
            this.rdo_nam.TabStop = true;
            this.rdo_nam.Text = "Nam";
            this.rdo_nam.UseVisualStyleBackColor = true;
            // 
            // txt_TenKH
            // 
            this.txt_TenKH.Location = new System.Drawing.Point(139, 94);
            this.txt_TenKH.Name = "txt_TenKH";
            this.txt_TenKH.Size = new System.Drawing.Size(169, 22);
            this.txt_TenKH.TabIndex = 5;
            // 
            // txt_MaKH
            // 
            this.txt_MaKH.Location = new System.Drawing.Point(139, 43);
            this.txt_MaKH.Name = "txt_MaKH";
            this.txt_MaKH.Size = new System.Drawing.Size(169, 22);
            this.txt_MaKH.TabIndex = 4;
            // 
            // lbl_SoTien
            // 
            this.lbl_SoTien.AutoSize = true;
            this.lbl_SoTien.Location = new System.Drawing.Point(6, 259);
            this.lbl_SoTien.Name = "lbl_SoTien";
            this.lbl_SoTien.Size = new System.Drawing.Size(105, 16);
            this.lbl_SoTien.TabIndex = 2;
            this.lbl_SoTien.Text = "So tien tai khoan";
            // 
            // lbl_MaCK
            // 
            this.lbl_MaCK.AutoSize = true;
            this.lbl_MaCK.Location = new System.Drawing.Point(6, 204);
            this.lbl_MaCK.Name = "lbl_MaCK";
            this.lbl_MaCK.Size = new System.Drawing.Size(108, 16);
            this.lbl_MaCK.TabIndex = 3;
            this.lbl_MaCK.Text = "Ma Chung Khoan";
            // 
            // lbl_Gioi
            // 
            this.lbl_Gioi.AutoSize = true;
            this.lbl_Gioi.Location = new System.Drawing.Point(6, 149);
            this.lbl_Gioi.Name = "lbl_Gioi";
            this.lbl_Gioi.Size = new System.Drawing.Size(31, 16);
            this.lbl_Gioi.TabIndex = 2;
            this.lbl_Gioi.Text = "Gioi";
            // 
            // lbl_TenKH
            // 
            this.lbl_TenKH.AutoSize = true;
            this.lbl_TenKH.Location = new System.Drawing.Point(6, 97);
            this.lbl_TenKH.Name = "lbl_TenKH";
            this.lbl_TenKH.Size = new System.Drawing.Size(107, 16);
            this.lbl_TenKH.TabIndex = 1;
            this.lbl_TenKH.Text = "Ten Khach Hang";
            // 
            // lbl_MaKH
            // 
            this.lbl_MaKH.AutoSize = true;
            this.lbl_MaKH.Location = new System.Drawing.Point(6, 43);
            this.lbl_MaKH.Name = "lbl_MaKH";
            this.lbl_MaKH.Size = new System.Drawing.Size(102, 16);
            this.lbl_MaKH.TabIndex = 0;
            this.lbl_MaKH.Text = "Ma Khach Hang";
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(337, 394);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 23);
            this.btn_save.TabIndex = 7;
            this.btn_save.Text = "save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_exit2
            // 
            this.btn_exit2.Location = new System.Drawing.Point(647, 388);
            this.btn_exit2.Name = "btn_exit2";
            this.btn_exit2.Size = new System.Drawing.Size(75, 23);
            this.btn_exit2.TabIndex = 8;
            this.btn_exit2.Text = "Exit";
            this.btn_exit2.UseVisualStyleBackColor = true;
            this.btn_exit2.Click += new System.EventHandler(this.btn_exit2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_exit2);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cb_MaCK;
        private System.Windows.Forms.TextBox txt_SoTien;
        private System.Windows.Forms.RadioButton rdo_Nu;
        private System.Windows.Forms.RadioButton rdo_nam;
        private System.Windows.Forms.TextBox txt_TenKH;
        private System.Windows.Forms.TextBox txt_MaKH;
        private System.Windows.Forms.Label lbl_SoTien;
        private System.Windows.Forms.Label lbl_MaCK;
        private System.Windows.Forms.Label lbl_Gioi;
        private System.Windows.Forms.Label lbl_TenKH;
        private System.Windows.Forms.Label lbl_MaKH;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_exit2;
    }
}